window._config = {
    cognito: {
        userPoolId: 'eu-north-1_lerq3sfYS', 
        userPoolClientId: '4qu5fhqmq8m5j38o2kb2spfv7d', 
        region: 'eu-north-1' 
    },
    api: {
        invokeUrl: '' 
    }
};
